<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <div class="mb-1 space-between-elements">
            <h2 class="mt-3">Alocar produto</h2>
            <ol class="breadcrumb mb-3 mt-3">
                <li class="breadcrumb-item"><a href="/dashboard">Início</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('consultor.index')); ?>">Consultores</a></li>
                <li class="breadcrumb-item active">Alocar produto</li>
            </ol>
        </div>

        <div class="card mb-4 border-light shadow">
            <div class="card-header space-between-elements">
                <span>Alocar produto - <b> <?php echo e($consultor->nome); ?> </b></span>
            </div>

            <div class="card-body">

                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

                <form class="row g-3" action="<?php echo e(route('produto.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <input type="hidden" name="consultor_id" id="consultor_id" value="<?php echo e($consultor->id); ?>">
                    <input type="hidden" name="consultor" id="consultor" value="<?php echo e($consultor->nome); ?>">
                    <div class="col-12">
                        <label for="name" class="form-label">Nome do produto:</label>
                        <input type="text" class="form-control" name="nome" id="nome" value="<?php echo e(old('nome')); ?>"
                            placeholder="Nome do produto">
                    </div>
                    <div class="col-12">
                        <label for="preco_fornecedor">Preço do Fornecedor:</label>
                        <input type="text" class="form-control" name="preco_fornecedor" id="preco_fornecedor"
                            value="<?php echo e(old('preco_fornecedor')); ?>" placeholder="R$">
                    </div>
                    <div class="col-12">
                        <label for="preco_final">Preço Final:</label>
                        <input type="text" class="form-control" name="preco_final" id="preco_final"
                            value="<?php echo e(old('preco_final')); ?>" placeholder="R$">
                    </div>
                    <div class="col-12">
                        <label for="comissao_consultor">Comissão do consultor (%)</label>
                        <input type="number" class="form-control" name="comissao_consultor" id="comissao_consultor"
                            value="<?php echo e(old('comissao_consultor')); ?>" placeholder="Comissão do consultor (%)">
                    </div>
                    <div class="col-12">
                        <label for="data_venda">Data da venda</label>
                        <input type="date" class="form-control" name="data_venda" id="data_venda"
                            value="<?php echo e(old('data_venda')); ?>" placeholder="Data">
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <label for="situacao" class="form-label">Situação</label>
                        <select class="form-select" name="situacao">
                            <option selected></option>
                            <option value="Em estoque">Em estoque</option>
                            <option value="Vendido">Vendido</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary bt-sm">Alocar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\will-\Desktop\projetos\sgkm\resources\views/produtos/create.blade.php ENDPATH**/ ?>