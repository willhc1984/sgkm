<?php if(session('success')): ?>
    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            Swal.fire({
                title: 'Pronto!',
                html: '<?php echo e(session('success')); ?>',
                icon: 'success'
            });
        });
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            Swal.fire({
                title: 'Erro:',
                html: '<?php echo e(session('error')); ?>',
                icon: 'error'
            });
        });
    </script>
<?php endif; ?>

<?php if($errors->any()): ?>
    <?php
        $message = '';
        foreach ($errors->all() as $error) {
            $message .= $error . '<br>';
        }
    ?>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            Swal.fire({
                title: 'Erro:',
                html: '<?php echo $message; ?>',
                icon: 'error'
            });
        });
    </script>

<?php endif; ?><?php /**PATH C:\Users\will-\Desktop\projetos\sgkm\resources\views/components/alert.blade.php ENDPATH**/ ?>