<?php $__env->startSection('content'); ?>
    <div id="layoutAuthentication" style="background-image:url(<?php echo e(url('img/fundo3.jpg')); ?>); background-repeat: no-repeat; background-size: 100% 100%;">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-5">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-1 mt-4">Sistema de Gestão</h3>
                                    <div class="d-flex justify-content-center mt-4 mb-4"> <img src="<?php echo e(asset('/img/logo.png')); ?>" /></div>
                                </div>
                                <div class="card-body">
                                    
                                    <?php if (isset($component)) { $__componentOriginalfb1a3ffb9cd3076cf8455b7289867b56 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfb1a3ffb9cd3076cf8455b7289867b56 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-login','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert-login'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfb1a3ffb9cd3076cf8455b7289867b56)): ?>
<?php $attributes = $__attributesOriginalfb1a3ffb9cd3076cf8455b7289867b56; ?>
<?php unset($__attributesOriginalfb1a3ffb9cd3076cf8455b7289867b56); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfb1a3ffb9cd3076cf8455b7289867b56)): ?>
<?php $component = $__componentOriginalfb1a3ffb9cd3076cf8455b7289867b56; ?>
<?php unset($__componentOriginalfb1a3ffb9cd3076cf8455b7289867b56); ?>
<?php endif; ?>
                                    <form action="<?php echo e(route('login.process')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="email" name="email" type="email"
                                                value="<?php echo e(old('email')); ?>" placeholder="Seu e-mail" />
                                            <label for="email">E-mail</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="password" type="password" name="password"
                                                    value="<?php echo e(old('password')); ?>" placeholder="Sua senha" />
                                                <label for="password">Senha</label>
                                            </div>
                                            
                                            <div class="d-flex align-items-center justify-content-center mt-4 mb-0">
                                                <button type="submit" class="btn btn-primary" href="#">Acessar</a>
                                            </div>
                                    </form>
                                </div>            
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\will-\Desktop\projetos\sgkm\resources\views/login/index.blade.php ENDPATH**/ ?>