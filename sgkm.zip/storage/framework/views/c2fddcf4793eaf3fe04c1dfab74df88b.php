<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>S.G.K.M - Produtos</title>
</head>

<body styles="font-size: 12px">
    <h2 style="text-align: center">Produtos</h2>

    <table style="border-collapse: collapse; width: 100%">
        <thead>
            <tr style="background-color: #adb5bd">
                <th style="border: 1px solid #ccc;">Nome</th>
                <th style="border: 1px solid #ccc;">Preço-Final</th>
                <th style="border: 1px solid #ccc;">Consultor</th>
                <th style="border: 1px solid #ccc;">Comissão</th>
                <th style="border: 1px solid #ccc;">Lucro Consultor</th>
                <th style="border: 1px solid #ccc;">Data da venda</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td style="border: 1px solid #ccc; text-align: center"><?php echo e($produto->nome); ?></td>
                    <td style="border: 1px solid #ccc; text-align: center">
                        <?php echo e('R$ ' . number_format($produto->preco_final, 2, ',', '.')); ?></td>
                    <td style="border: 1px solid #ccc; text-align: center"><?php echo e($produto->consultor->nome); ?></td>
                    <td style="border: 1px solid #ccc; text-align: center"><?php echo e($produto->comissao_consultor); ?> %</td>
                    <td style="border: 1px solid #ccc; text-align: center">
                        <?php echo e('R$ ' . number_format($produto->lucro_consultor, 2, ',', '.')); ?></td>
                    <td style="border: 1px solid #ccc; text-align: center">
                        <?php echo e(\Carbon\Carbon::parse($produto->data_venda)->format('d/m/Y')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">Nenhum produto encontrado!</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <p class="text-center"> Total de produtos: <b><span class="badge bg-success"> <?php echo e($produtos->count()); ?>

            </span></b></p>
    <p class="text-center"> Total bruto: <b><span class="badge bg-success"> R$
                <?php echo e(number_format($produtos->sum('preco_final'), 2, ',', '.')); ?> </span></b></p>
    <p class="text-center"> Comissão total do consultor(a): <b><span class="badge bg-success">R$
                <?php echo e(number_format($produtos->sum('lucro_consultor'), 2, ',', '.')); ?> </i></b>
    </p>

</body>


</html>
<?php /**PATH C:\Users\will-\Desktop\projetos\sgkm\resources\views/produtos/generate-pdf.blade.php ENDPATH**/ ?>