<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <div class="mb1 space-between-elements">
            <h2 class="mt-3">Produtos</h2>
            <ol class="breadcrumb mb-3 mt-3 p-1 rounded bg-light">
                <li class="breadcrumb-item"><a class="text-decoration-none" href="#">Início</a></li>
                <li class="breadcrumb-item active">Produtos</li>
            </ol>
        </div>

        <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

        <div class="card mb-4 border-light shadow">
            <div class="card-header space-between-elements">
                <span>Pesquisar</span>
            </div>
            <div class="card-body">
                <form action="#">
                    <div class="row">
                        <div class="col-md-4 col-sm-12">
                            <label class="form-label" for="name">Nome:</label>
                            <input type="text" name="nome" id="nome" class="form-control" value=""
                                placeholder="Nome do produto">
                        </div>
                        <div class="col-md-4 col-sm-12">
                            <label class="form-label" for="name">Consultor:</label>
                            <select class="form-select" name="consultor" id="consultor" aria-label="Default select example">
                                <option selected></option>
                                <?php $__empty_1 = true; $__currentLoopData = $consultores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($consultor->id); ?>"><?php echo e($consultor->nome); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="col-md-4 col-sm-12">
                            <label class="form-label" for="name">Situação:</label>
                            <select class="form-select" name="situacao" id="situacao" aria-label="Default select example">
                                <option selected></option>
                                <option value="Em estoque">Em estoque</option>
                                <option value="Vendido">Vendido</option>
                                <option value="Pago">Pago</option>
                            </select>
                        </div>
                        <div class="col-md-4 col-sm-12">
                            <label class="form-label" for="data_inicio">Data início:</label>
                            <input type="date" name="data_inicio" id="data_inicio" class="form-control" value=""
                                placeholder="Data final">
                        </div>
                        <div class="col-md-4 col-sm-12">
                            <label class="form-label" for="data_fim">Data final:</label>
                            <input type="date" name="data_fim" id="data_fim" class="form-control" value=""
                                placeholder="Data final">
                        </div>
                        <div class="col-md-4 col-sm-12">
                            <label class="form-label" for="qtde">Registros:</label>
                            <input type="number" name="qtde" id="qtde" class="form-control" value=""
                                placeholder="Quantidade de registros exibidos">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 col-sm-12 mt-2 pt-2">
                            <button type="submit" class="btn btn-info btn-sm"><i class="fa-solid fa-magnifying-glass">
                                </i> Pesquisar</button>
                            <a href="<?php echo e(route('produto.index')); ?>" class="btn btn-warning btn-sm"><i
                                    class="fa-solid fa-trash"></i>Limpar</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card mb-4 border-light shadow">
            <div class="card-header space-between-elements">
                <span>Listar</span>
            </div>

            <div class="card-body">
                <table class="table table-hover table-sm" style="font-size: 13px;">
                    <thead>
                        <tr class="text-center">
                            
                            <th scope="col">Nome</th>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-produtos')): ?>
                                <th scope="col">Preço-Fornecedor</th>
                            <?php endif; ?>
                            <th scope="col">Preço-Final</th>
                            <th scope="col">Consultor</th>
                            <th scope="col">Comissão</th>
                            <th scope="col">Lucro Consultor</th>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-produtos')): ?>
                                <th scope="col">Lucro Loja</th>
                            <?php endif; ?>
                            <th scope="col">Data da venda</th>
                            <th scope="col">Situação</th>
                            <th scope="col">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                
                                <td class="text-center nomeProduto" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="<?php echo e($produto->nome); ?>"><?php echo e($produto->nome); ?></td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-produtos')): ?>
                                    <td class="text-center"><?php echo e('R$ ' . number_format($produto->preco_fornecedor, 2, ',', '.')); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo e('R$ ' . number_format($produto->preco_final, 2, ',', '.')); ?></td>
                                <td class="text-center"><?php echo e($produto->consultor->nome); ?></td>
                                <td class="text-center"><?php echo e($produto->comissao_consultor); ?> %</td>
                                <td class="text-center"><?php echo e('R$ ' . number_format($produto->lucro_consultor, 2, ',', '.')); ?>

                                </td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-produtos')): ?>
                                    <td class="text-center"><?php echo e('R$ ' . number_format($produto->lucro_loja, 2, ',', '.')); ?>

                                    </td>
                                <?php endif; ?>
                                <?php if(empty($produto->data_venda)): ?>
                                    <td class="text-center" style="color: red;">Não informado</td>
                                <?php else: ?>
                                    <td class="text-center">
                                        <?php echo e(\Carbon\Carbon::parse($produto->data_venda)->format('d/m/Y')); ?></td>
                                <?php endif; ?>
                                <td class="text-center">
                                    <?php if($produto->situacao == 'Vendido'): ?>
                                        <a href="<?php echo e(route('produto.index')); ?>">
                                            <span class="badge bg-success">Vendido</span>
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('produto.index')); ?>">
                                            <span class="badge bg-danger">Em estoque</span>
                                        </a>
                                    <?php endif; ?>

                                <td class="d-md-flex justify-content-center">

                                    <a href="<?php echo e(route('produto.edit', ['produto' => $produto->id])); ?>"
                                        class="btn btn-secondary btn-sm me-1 mb-1">
                                        <i class="fa-solid fa-pen-to-square"></i></a>

                                    <form id="formDelete<?php echo e($produto->id); ?>" method="POST"
                                        action="<?php echo e(route('produto.destroy', ['produto' => $produto->id])); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm me-1 mb-1 btnDelete"
                                            data-delete-id="<?php echo e($produto->id); ?>"><i class="fa-regular fa-trash-can"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="alert alert-danger" role="alert">
                                Nenhum produto encontrado!
                            </div>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php echo e($produtos->onEachSide(2)->links()); ?>


                <h2 class="text-center mt-5 mb-3">Resultados para esta página</h2>

                <p class="text-center"> Total de produtos: <b><span class="badge bg-success"> <?php echo e($produtos->count()); ?>

                        </span></b></p>
                <p class="text-center"> Total bruto: <b><span class="badge bg-success"> R$
                            <?php echo e(number_format($produtos->sum('preco_final'), 2, ',', '.')); ?> </span></b></p>
                <p class="text-center"> Comissão total do consultor(a): <b><span class="badge bg-success">R$
                            <?php echo e(number_format($produtos->sum('lucro_consultor'), 2, ',', '.')); ?> </i></b>
                </p>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-produtos')): ?>
                <p class="text-center">Total preço de custo: <b><span class="badge bg-success">R$
                            <?php echo e(number_format($produtos->sum('preco_fornecedor'), 2, ',', '.')); ?> </i></b>
                </p>
                <p class="text-center"> Lucro total a loja: <b><span class="badge bg-success">R$
                            <?php echo e(number_format($produtos->sum('lucro_loja'), 2, ',', '.')); ?> </i></b>
                </p>
                <?php endif; ?>

                <div class="alert alert-warning" role="alert">
                    <b>Obs..:</b> Utilize os filtros de modo a exibir todos os registros na mesma página
                    para correto cálculo de valores.
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\will-\Desktop\projetos\sgkm\resources\views/produtos/index.blade.php ENDPATH**/ ?>