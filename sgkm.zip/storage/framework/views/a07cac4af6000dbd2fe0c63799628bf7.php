

<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <div class="row mt-5">
            <div class="d-flex justify-content-center mt-4 mb-4"> <img src="<?php echo e(asset('/img/exclamation.png')); ?>" /></div>
            <h3 class="text-center font-weight-light my-1 mt-4">Página não encontrada!</h3>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\will-\Desktop\projetos\sgkm\resources\views/errors/404.blade.php ENDPATH**/ ?>