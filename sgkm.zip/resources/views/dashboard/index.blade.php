@extends('layouts.admin')

@section('content')
    <div class="container-fluid px-4">

        <h3 class="text-center font-weight-light my-5 mt-5">S.G.K.M.</h3>
        <div class="d-flex justify-content-center mt-4"> <img src="{{ asset('/img/logo.png') }}" /></div>

    </div>
@endsection
