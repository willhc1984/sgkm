@extends('layouts.admin')

@section('content')
    <div class="container-fluid px-4">
        <div class="row mt-5">
            <div class="d-flex justify-content-center mt-4 mb-4"> <img src="{{ asset('/img/lock3.png') }}" /></div>
            <h3 class="text-center font-weight-light my-1 mt-4">Sem permissão!</h3>
        </div>
    </div>
@endsection
